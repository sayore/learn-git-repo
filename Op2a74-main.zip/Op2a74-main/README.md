# Op2a74

# 🎨 Java Design Patterns — Quick Guide  
![Creational](https://img.shields.io/badge/Category-Creational-4c1) ![Structural](https://img.shields.io/badge/Category-Structural-blue) ![Behavioral](https://img.shields.io/badge/Category-Behavioral-orange)



## English

### 🏭 Factory (Creational)
**Idea:** Encapsulates object creation based on input or context, returning a suitable subtype without exposing construction details.  
**When to use:** You have multiple implementations of an interface and want a single entry point to decide which one to create.

### 🧪 Abstract Factory (Creational)
**Idea:** Produces families of related objects (that work well together) without specifying concrete classes.  
**When to use:** You need to switch entire “themes” or “product families” (e.g., GUI widgets for different OS skins).

### 🔌 Adapter (Structural)
**Idea:** Lets incompatible interfaces work together by wrapping an existing class in a new interface.  
**When to use:** You must integrate third-party/legacy code that doesn’t match your app’s expected interface.

### 🎀 Decorator (Structural)
**Idea:** Adds responsibilities to objects dynamically by wrapping them, avoiding subclass explosion.  
**When to use:** You need optional, combinable features (e.g., buffering + compression + encryption for streams).

### 🧠 Strategy (Behavioral)
**Idea:** Defines a family of algorithms, encapsulates each, and makes them interchangeable at runtime.  
**When to use:** You want to swap algorithms (sorting, pricing, routing) without changing the caller.

### 👀 Observer (Behavioral)
**Idea:** Establishes a one-to-many dependency so that observers are notified automatically when the subject changes.  
**When to use:** Event-driven updates (GUIs, domain events, cache invalidation, pub/sub).

---

## Deutsch

### 🏭 Factory (Erzeugungsmuster)
**Idee:** Kapselt die Objekterzeugung basierend auf Eingaben/Kontext und liefert den passenden Subtyp, ohne Konstruktionsdetails offenzulegen.  
**Einsatz:** Mehrere Implementierungen eines Interfaces, eine zentrale Stelle entscheidet, welche Instanz erstellt wird.

### 🧪 Abstract Factory (Erzeugungsmuster)
**Idee:** Erzeugt Familien zusammengehöriger Objekte, ohne konkrete Klassen zu nennen.  
**Einsatz:** Ganzen „Themenwelten“/„Produktfamilien“ wechseln (z. B. GUI-Widgets für verschiedene Betriebssysteme).

### 🔌 Adapter (Strukturmuster)
**Idee:** Lässt inkompatible Schnittstellen zusammenarbeiten, indem eine bestehende Klasse in ein neues Interface „eingepasst“ wird.  
**Einsatz:** Integration von Fremd-/Legacy-Code, der nicht zum erwarteten Interface passt.

### 🎀 Decorator (Strukturmuster)
**Idee:** Fügt Objekten dynamisch Verantwortlichkeiten hinzu, indem sie umhüllt werden; vermeidet Subklassen-Explosion.  
**Einsatz:** Optionale, kombinierbare Features (z. B. Pufferung + Kompression + Verschlüsselung bei Streams).

### 🧠 Strategy (Verhaltensmuster)
**Idee:** Definiert eine Familie von Algorithmen, kapselt jeden und macht sie zur Laufzeit austauschbar.  
**Einsatz:** Algorithmen (Sortierung, Preisberechnung, Routing) flexibel austauschen, ohne Aufrufer zu ändern.

### 👀 Observer (Verhaltensmuster)
**Idee:** Stellt eine 1-zu-n-Abhängigkeit her; Beobachter werden automatisch benachrichtigt, wenn sich der Zustand des Subjekts ändert.  
**Einsatz:** Ereignisgesteuerte Aktualisierung (GUIs, Domain-Events, Cache-Invalidierung, Pub/Sub).

---

## 🧭 Summary Table / Vergleichstabelle

| # | Design Pattern | Category / Kategorie | Use Cases / Einsatz | Pros / Vorteile | Cons / Nachteile |
|---|----------------|----------------------|---------------------|-----------------|------------------|
| 1 | 🏭 **Factory** | Creational / Erzeugung | Choose implementation by input; centralize creation; hide constructors. <br> Auswahl der Implementierung; zentrale Erzeugung; Konstruktoren verbergen. | Decouples callers from concrete types; single creation point. <br> Entkoppelt Aufrufer; zentrale Fabriklogik. | Can centralize too much logic; may grow complex switch/if trees. <br> Logikballung; komplexe Verzweigungen. |
| 2 | 🧪 **Abstract Factory** | Creational / Erzeugung | Switch product families/themes (UI kits, DB drivers). <br> Produktfamilien/Themes wechseln (UI-Kits, DB-Treiber). | Ensures compatible products; easy family swap. <br> Kompatible Produkte; einfacher Familienwechsel. | Adds indirection; many interfaces/classes. <br> Mehr Abstraktion; zusätzliche Klassen. |
| 3 | 🔌 **Adapter** | Structural / Struktur | Integrate legacy/3rd-party APIs; unify interfaces. <br> Legacy/Fremd-APIs integrieren; Schnittstellen vereinheitlichen. | Reuse existing code; smooth integration. <br> Wiederverwendung; nahtlose Integration. | Another layer to maintain; may hide inefficiencies. <br> Zusätzliche Schicht; evtl. Ineffizienzen verdeckt. |
| 4 | 🎀 **Decorator** | Structural / Struktur | Add features dynamically (I/O pipelines). <br> Funktionen dynamisch hinzufügen (I/O-Pipelines). | Composable features; avoids subclass explosion. <br> Komponierbar; vermeidet Klassenexplosion. | Deep wrapper stacks can complicate debugging. <br> Verschachtelungen erschweren Debugging. |
| 5 | 🧠 **Strategy** | Behavioral / Verhalten | Swap algorithms at runtime (pricing, sorting). <br> Algorithmen zur Laufzeit tauschen. | Open/closed friendly; cleaner testing. <br> OCP-freundlich; besser testbar. | More objects; strategy selection logic needed. <br> Mehr Objekte; Auswahl-Logik erforderlich. |
| 6 | 👀 **Observer** | Behavioral / Verhalten | Event broadcasting; reactive UIs; domain events. <br> Ereignisverteilung; reaktive UIs; Domain-Events. | Loose coupling; automatic updates. <br> Lose Kopplung; automatische Updates. | Ordering/race issues; potential memory leaks if not unsubscribed. <br> Reihenfolge/Rennen; Leaks ohne Abmeldung. |

---

## ✅ Quick Tips / Kurzhinweise
- **Start simple:** Prefer Factory before Abstract Factory; upgrade when you see a *family* need.  
  **Einfach beginnen:** Erst Factory, dann Abstract Factory, wenn *Familien* nötig werden.
- **Prefer composition:** Decorator & Strategy emphasize composition over inheritance.  
  **Komposition bevorzugen:** Decorator & Strategy setzen auf Komposition statt Vererbung.
- **Mind lifecycle:** Observer requires careful subscribe/unsubscribe management.  
  **Lebenszyklus beachten:** Bei Observer sauber an-/abmelden.

---

 

# Tools
- [X] Git / GitHub / GitHub Desktop
- [X] DrawIO
- [X] MerMaid
- [X] Markdown

