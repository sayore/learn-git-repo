// ------------------------------
// Singleton: RestaurantRegistry
// ------------------------------
import java.util.*;

final class RestaurantRegistry {
    // Lazy-loaded holder für threadsicheren Singleton
    private RestaurantRegistry() {}
    private static class Holder {
        private static final RestaurantRegistry INSTANCE = new RestaurantRegistry();
    }
    public static RestaurantRegistry getInstance() { return Holder.INSTANCE; }

    private final Map<String, Object> settings = new HashMap<>();
    private int nextOrderId = 1;

    {
        settings.put("tax_rate", 0.07); // 7 %
        settings.put("name", "Neighborhood Bistro");
    }

    public synchronized int nextOrderId() {
        return nextOrderId++;
    }

    public double getTaxRate() {
        return (double) settings.getOrDefault("tax_rate", 0.0);
    }
}

// ------------------------------
// Strategy: Preisstrategien
// ------------------------------
interface PricingStrategy {
    double price(double base);
}

class RegularPricing implements PricingStrategy {
    public double price(double base) {
        double tax = RestaurantRegistry.getInstance().getTaxRate();
        return Math.round(base * (1 + tax) * 100.0) / 100.0;
    }
}

class HappyHourPricing implements PricingStrategy {
    public double price(double base) {
        double tax = RestaurantRegistry.getInstance().getTaxRate();
        double discounted = base * 0.8;
        return Math.round(discounted * (1 + tax) * 100.0) / 100.0;
    }
}

// ------------------------------
// Abstract Factory: Küchen
// ------------------------------
abstract class MenuItem {
    public final String name;
    public final double basePrice;
    protected MenuItem(String name, double basePrice) {
        this.name = name; this.basePrice = basePrice;
    }
}

interface CuisineFactory {
    MenuItem createMainDish();
    MenuItem createDessert();
}

class ItalianFactory implements CuisineFactory {
    public MenuItem createMainDish() { return new MenuItem("Margherita Pizza", 10.0){}; }
    public MenuItem createDessert()  { return new MenuItem("Tiramisu", 6.0){}; }
}

class JapaneseFactory implements CuisineFactory {
    public MenuItem createMainDish() { return new MenuItem("Salmon Sushi Set", 12.0){}; }
    public MenuItem createDessert()  { return new MenuItem("Mochi", 5.0){}; }
}

// ------------------------------
// Observer: Bestellstatus-Updates
// ------------------------------
interface Observer {
    void update(Order order);
}

class Order {
    private final int id;
    private final List<MenuItem> items = new ArrayList<>();
    private final List<Observer> observers = new ArrayList<>();
    private String status = "NEW";
    private PricingStrategy strategy;

    public Order(PricingStrategy strategy) {
        this.id = RestaurantRegistry.getInstance().nextOrderId();
        this.strategy = strategy;
    }

    public int getId() { return id; }
    public String getStatus() { return status; }
    public void attach(Observer o) { observers.add(o); }
    public void detach(Observer o) { observers.remove(o); }

    public void setStatus(String s) {
        this.status = s;
        // alle Beobachter benachrichtigen
        for (Observer o: new ArrayList<>(observers)) {
            o.update(this);
        }
    }

    public void addItem(MenuItem item) { items.add(item); }

    public double total() {
        double base = items.stream().mapToDouble(i -> i.basePrice).sum();
        return strategy.price(base);
    }
}

class KitchenDisplay implements Observer {
    public void update(Order order) {
        System.out.println("[Kitchen] Bestellung #" + order.getId() + " ist jetzt " + order.getStatus());
    }
}

class CustomerNotifier implements Observer {
    private final String phone;
    public CustomerNotifier(String phone) { this.phone = phone; }
    public void update(Order order) {
        if ("READY".equals(order.getStatus())) {
            System.out.println("[SMS an " + phone + "] Ihre Bestellung #" + order.getId() + " ist fertig!");
        }
    }
}

// ------------------------------
// Factory Method: Zahlung
// ------------------------------
interface PaymentProcessor {
    void pay(double amount);
}

class CashProcessor implements PaymentProcessor {
    public void pay(double amount) {
        System.out.printf("[Barzahlung] Eingezogen: %.2f $%n", amount);
    }
}

class CardProcessor implements PaymentProcessor {
    public void pay(double amount) {
        System.out.printf("[Karte] Belastet: %.2f $%n", amount);
    }
}

abstract class PaymentCreator {
    protected abstract PaymentProcessor createProcessor();
}

class CashCreator extends PaymentCreator {
    protected PaymentProcessor createProcessor() { return new CashProcessor(); }
}

class CardCreator extends PaymentCreator {
    protected PaymentProcessor createProcessor() { return new CardProcessor(); }
}

// ------------------------------
// Demo-Ablauf
// ------------------------------
public class RestaurantApp {
    public static void main(String[] args) {
        // Küchenfamilie auswählen
        CuisineFactory cuisine = new ItalianFactory(); // oder new JapaneseFactory()

        // Preisstrategie auswählen
        PricingStrategy pricing = new HappyHourPricing(); // oder new RegularPricing()

        // Bestellung aufbauen und Beobachter anhängen
        Order order = new Order(pricing);
        order.attach(new KitchenDisplay());
        order.attach(new CustomerNotifier("+49-123-456"));

        // Menüelemente aus gewählter Küche hinzufügen
        order.addItem(cuisine.createMainDish());
        order.addItem(cuisine.createDessert());

        // Statusänderungen -> Observer-Benachrichtigungen
        order.setStatus("PREPARING");
        order.setStatus("READY");

        // Preisberechnung via Strategy
        double amount = order.total();
        System.out.printf("GESAMT für Bestellung #%d: %.2f $%n", order.getId(), amount);

        // Zahlungsart über Factory Method wählen
        PaymentCreator creator = new CardCreator(); // oder CashCreator
        PaymentProcessor processor = creator.createProcessor();
        processor.pay(amount);
    }
}