// Thread-safe lazy initialization using holder idiom
class Config {
    private Config() {} // private constructor prevents external instantiation

    private static class Holder {
        private static final Config INSTANCE = new Config();
    }

    public static Config getInstance() {
        return Holder.INSTANCE; // created on first access
    }

    // Example method
    public String get(String key) {
        return "value-for-" + key; // placeholder
    }
}

class SingleTon {
    public static void main(String[] args) {
        Config cfg1 = Config.getInstance();
        Config cfg2 = Config.getInstance();
        System.out.println(cfg1 == cfg2); // true

    }
}