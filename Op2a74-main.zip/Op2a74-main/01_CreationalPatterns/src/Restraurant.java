
interface Dish{
    String getName();
    double getPrice();
}

class Pizza implements Dish{
    @Override
    public String getName(){
        return "Margherita";
    }

    @Override
    public double getPrice(){
        return 9.5;
    }
}


class Salat implements Dish{
    @Override
    public String getName(){
        return "Normal Salat";
    }

    @Override
    public double getPrice(){
        return 6.5;
    }
}



class DishFactory {

        public Dish prepareDish(String type){
            switch (type){
                case "Pizza": return new Pizza();
                case "Salat": return new Salat();
                default:
                    throw new IllegalArgumentException("Unknown Dish Type");
            }
    }

}


public class Restraurant {

    public static void main(String[] args) {
        DishFactory factory = new DishFactory();

        Dish d1 = factory.prepareDish("Pizza");
        Dish d2 = factory.prepareDish("Salat");

        System.out.println(d1.getName() + " costs " + d1.getPrice());

        System.out.println(d2.getName() + " costs " + d2.getPrice());
    }
}
