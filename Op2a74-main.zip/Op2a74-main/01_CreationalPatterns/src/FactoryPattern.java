
interface BurgerF{
    void prepare();
    void cook();
    void box();
}


class VeggieBurgerF implements BurgerF{

    @Override
    public void prepare() {
        System.out.println("Preparing Vegging Burger");
    }
    @Override
    public void cook() {
        System.out.println("Cooking Vegging Burger");
    }
    @Override
    public void box() {
        System.out.println("Boxing Vegging Burger");
    }
}

class ChickenBurgerF implements BurgerF{
    @Override
    public void prepare() {
        System.out.println("Preparing Chicken Burger");
    }
    @Override
    public void cook() {
        System.out.println("Cooking Chicken Burger");
    }
    @Override
    public void box() {
        System.out.println("Boxing Chicken Burger");
    }
}


class BEEFBurgerF implements BurgerF{
    @Override
    public void prepare() {
        System.out.println("Preparing Beef Burger");
    }
    @Override
    public void cook() {
        System.out.println("Cooking Beef Burger");
    }
    @Override
    public void box() {
        System.out.println("Boxing Beef Burger");
    }
}


class BurgerFactory{
    public  BurgerF createBurger(BurgerType type){
        switch (type){
            case VEGGIE:
                return new VeggieBurgerF(); // Specific Class Burger Implementation
            case CHICKEN:
                return new ChickenBurgerF(); // Specific Class Burger Implementation
            case BEEF:
                return new BEEFBurgerF(); // Specific Class Burger Implementation
            default:
                throw new IllegalArgumentException("Unknown Burger Type:" + type);
        }
    }
}




// Enum Burger Type
enum BurgerType{
    VEGGIE,
    CHICKEN,
    BEEF
}


// Client Code
public class FactoryPattern {

    public static void main(){

        BurgerFactory factory = new BurgerFactory();

        BurgerF b1 = factory.createBurger(BurgerType.VEGGIE);
        b1.prepare();
        b1.cook();
        b1.box();


        BurgerF b2 = factory.createBurger(BurgerType.BEEF);
        b2.prepare();
        b2.cook();
        b2.box();
    }
}
