import java.util.*;

interface BurgerPlain {
    String name();

    double price();
}

abstract class BaseBurgerPlain implements BurgerPlain {
    protected String name;

    protected double price;

    @Override public String name() { return name; }
    @Override public double price() { return price; }
    @Override public String toString() {
        return name + " $" + price ;
    }
}

class VeggieBurgerPlain extends BaseBurgerPlain {
    public VeggieBurgerPlain() {
        this.name = "Veggie Burger";
        this.price = 6.50;

    }
}

class ChickenBurgerPlain extends BaseBurgerPlain {
    public ChickenBurgerPlain() {
        this.name = "Chicken Burger";
        this.price = 7.50;

    }
}

public class PlainBurger {
    public static void main(String[] args) {
        BurgerPlain b1 = new VeggieBurgerPlain();   // direct dependency on concrete class
        BurgerPlain b2 = new ChickenBurgerPlain();  // direct dependency on concrete class
        System.out.println(b1);
        System.out.println(b2);
    }
}