
interface BurgerAF{
    void prepare();
    void cook();
    void box();
}

class AmericanVeggieBurger implements BurgerAF{
    @Override
    public void prepare() {
        System.out.println("Preparing American Veggie Burger");
    }

    @Override
    public void cook() {
        System.out.println("Cooking American Veggie Burger");
    }

    @Override
    public void box() {
        System.out.println("Boxing American Veggie Burger");
    }
}

class IndienVeggieBurger implements BurgerAF{
    @Override
    public void prepare() {
        System.out.println("Preparing IN Veggie Burger");
    }

    @Override
    public void cook() {
        System.out.println("Cooking IN Veggie Burger");
    }

    @Override
    public void box() {
        System.out.println("Boxing IN Veggie Burger");
    }
}


class AmericanChickenBurger implements BurgerAF{
    @Override
    public void prepare() {
        System.out.println("Preparing AM CH Burger");
    }

    @Override
    public void cook() {
        System.out.println("Cooking AM CH Burger");
    }

    @Override
    public void box() {
        System.out.println("Boxing AM CH Burger");
    }
}


class IndienChickenBurger implements BurgerAF{
    @Override
    public void prepare() {
        System.out.println("Preparing IN CH Burger");
    }

    @Override
    public void cook() {
        System.out.println("Cooking IN CH Burger");
    }

    @Override
    public void box() {
        System.out.println("Boxing IN CH Burger");
    }
}



interface BurgerAFactory{
    BurgerAF createVeggieBurger();
    BurgerAF createChickenBurger();
}



class AmericanBurgerFactory implements  BurgerAFactory{
    @Override
    public BurgerAF createVeggieBurger()
    {
        return new AmericanVeggieBurger();
    }

    @Override
    public BurgerAF createChickenBurger()
    {
        return new AmericanChickenBurger();
    }
}


class IndienBurgerFactory implements  BurgerAFactory{
    @Override
    public BurgerAF createVeggieBurger()
    {
        return new IndienVeggieBurger();
    }

    @Override
    public BurgerAF createChickenBurger()
    {
        return new IndienChickenBurger();
    }
}




// Client Code
public class AbstractFactoryRestaurant {

    public static void main(String[] args) {


        // create Factories
        BurgerAFactory americanFactory = new AmericanBurgerFactory();
        BurgerAFactory indienFactory = new IndienBurgerFactory();

        // create burgers from the factories
        BurgerAF americanveggie1   =  americanFactory.createVeggieBurger();
        BurgerAF indienchicken1   =  indienFactory.createChickenBurger();

        // Use the instance
        americanveggie1.prepare();
        americanveggie1.cook();
        americanveggie1.box();


    }

}
