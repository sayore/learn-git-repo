interface PaymentProcessor {
    void pay(double amount);
}


// Legacy Class --> Operative Payment Gateway
class ExternalCardService{

    public void charge(double total){
        System.out.println("External Card Charge: " + total + "EURO");
    }
}

// New Class --> Adapter Class Code
class CardServiceAdapter implements PaymentProcessor{

    private ExternalCardService cardService;

    public CardServiceAdapter(ExternalCardService cardService){
        this.cardService = cardService;

    }


    public void pay(double amount){

        // Translates the "Pay" new method --> to the "Charge" old method
        this.cardService.charge(amount);
    }

}

// Client code
public class AdapterPattern {
    public static void main(String[] args) {

            // Create Instance of the Legacy Class ( Old Paypal 1.0, Old Visa 1.0)
            ExternalCardService old_payment = new ExternalCardService();


            // Create Instance of the New Class
            PaymentProcessor processor = new CardServiceAdapter(old_payment);



            //  Uses the New Code --> Payment Gateway
            processor.pay(5.0);

    }
}