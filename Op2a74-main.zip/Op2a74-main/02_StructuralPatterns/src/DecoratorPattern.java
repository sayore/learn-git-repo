interface BurgerD{
    String getName();
    double getPrice();
}

// 1. Base Burger
class VeggieBurgerD implements BurgerD{
    public String getName(){
        return "Veggie";
    }
    public double getPrice(){
        return 5.0;
    }
}

// 2. Base Burger
class ChickenBurgerD implements BurgerD{
    public String getName(){
        return "Chicken Burger";
    }
    public double getPrice(){
        return 5.0;
    }
}



// Abstract Decorator Class for Cheese and Ketchup, ....
abstract class BurgerDecorator implements BurgerD{
    protected BurgerD burger;

    public BurgerDecorator(BurgerD burger){ this.burger = burger;}

    public String getName(){return burger.getName();}
    public double getPrice(){return burger.getPrice();}

}


// First Decorator Cheese
class CheeseDecorator extends BurgerDecorator{
    public CheeseDecorator(BurgerD burger){super(burger);}


    @Override
    public String getName(){return burger.getName() + " Cheese";}

    @Override
    public double getPrice(){return burger.getPrice() + 1.5;}

}

// Second Decorator Ketchup
class KetchupDecorator extends BurgerDecorator{
    public KetchupDecorator(BurgerD burger){super(burger);}


    @Override
    public String getName(){return burger.getName() + " Ketchup";}

    @Override
    public double getPrice(){return burger.getPrice() + 0.5;}

}


// Third Decorator Mayo
class MayoDecorator extends BurgerDecorator{
    public MayoDecorator(BurgerD burger){super(burger);}


    @Override
    public String getName(){return burger.getName() + " Mayo";}

    @Override
    public double getPrice(){return burger.getPrice() + 0.3;}

}




// Client
public class DecoratorPattern {

    public static void main(String[] args) {

        // 1. Create the Base Burger
        BurgerD base = new ChickenBurgerD();  // Normal Burger (Base Burger)
        System.out.println("Name = " + base.getName() + " - " + base.getPrice() + " Euro");

        // 2. Add Cheese
        BurgerD cheeseBurger = new CheeseDecorator(base) ; // Add the Base Burger to the Cheese Decorator
        System.out.println("Name = " + cheeseBurger.getName() + " - " + cheeseBurger.getPrice() + " Euro");

        // 3. Add Ketchup
        BurgerD ketchupBurger = new KetchupDecorator(cheeseBurger); // Add the cheese Burger to the Ketchup Decorator
        System.out.println("Name = " + ketchupBurger.getName() + " - " + ketchupBurger.getPrice() + " Euro");


        // 4. Add Mayo
        BurgerD mayoBurger = new MayoDecorator(ketchupBurger); // Add the Ketchup Burger to the Mayo Decorator
        System.out.println("Name = " + mayoBurger.getName() + " - " + mayoBurger.getPrice() + " Euro");
    }

}
