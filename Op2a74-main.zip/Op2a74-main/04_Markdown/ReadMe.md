# Java Basic


Welcome to my **Java** ***Basics*** Summery.

## 1. If Statement

1. If 
2. If else
3. else




## 2. Loops

- for loop
- while loop


### 2.1 For Loop

### 2.2 While Loop


## 3. Java Simple Code

~~~java
System.out.println("Hello Mohamed");
System.out.println("Hello Mohamed");
System.out.println("Hello Mohamed");
System.out.println("Hello Mohamed");
System.out.println("Hello Mohamed");
~~~


~~~html
<p> Hello Mohamed </p>
~~~


~~~python
print("Hello Mohmaed")
print("Hello Mohmaed")
print("Hello Mohmaed")
print("Hello Mohmaed")
print("Hello Mohmaed")
~~~


# Quick Start

To download my application, click on [MyLink](www.google.com).


# Image


![TN](./TN.png)