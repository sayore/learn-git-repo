import java.util.*;

interface Observer{
    void update(String message);
}


// Observer
class Employee implements Observer{

    private String name;

    public Employee(String name){
        this.name = name;
    }


    @Override
    public void update(String message) {
        System.out.println(name + "  received a notification: " + message);
    }
}




interface Subject {
    void registerObserver(Observer o);
    void removeObserver(Observer o);
    void notifyObservers(String message);
}


class BurgerOrder implements Subject {

    // List of Subscribers / Observers
    private List<Observer> observers = new ArrayList<>();

    private String orderName;

    public BurgerOrder(String orderName){
        this.orderName = orderName;
    }

    @Override
    public void registerObserver(Observer o) {
        observers.add(o); // Add the Observer to the List of Observers
    }

    @Override
    public void removeObserver(Observer o) {
        observers.remove(o); // Unsubscribe the observer from the list
    }

    @Override
    public void notifyObservers(String message) {
        for(Observer o : observers){
            o.update(message);
        }
    }


    // State Change
    public void startingCooking(){
        System.out.println("Cooking started for the order: " + orderName);
        notifyObservers("Your order: "+ orderName + " is being cooked");
    }

    // State Change
    public void readyToServe(){
        System.out.println(orderName + " is ready to serve.");
        notifyObservers("Your order: "+ orderName + " is ready to serve!");
    }



}

// Client
public class ObserverPattern {

    public static void main(String[] args) {
        BurgerOrder order1 = new BurgerOrder("Chicken Burger");

        // Define Subscribers/Observers
        Employee waiter = new Employee("Thomas");
        Employee paymentcase = new Employee("Sara");
        Employee leader = new Employee("Lena");


        // Add/Register/Subscribe the Observers to the Order
        order1.registerObserver(waiter);
        order1.registerObserver(paymentcase);
        order1.registerObserver(leader);



        // Use the nofitication functionality

        order1.startingCooking();
        order1.readyToServe();

    }


}
