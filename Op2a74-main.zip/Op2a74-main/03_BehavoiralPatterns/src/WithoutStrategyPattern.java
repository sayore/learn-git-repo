interface Burger {
    void prepare();
    void cook();
}


class VeggieBurger implements Burger {
    @Override
    public void prepare() {
        System.out.println("Preparing Veggie Burger");
    }

    @Override
    public void cook() {
        System.out.println("Cooking Veggie Burger ");
    }
}

class ChickenBurger implements Burger {
    @Override
    public void prepare() {
        System.out.println("Preparing Chicken Burger .");
    }

    @Override
    public void cook() {
        System.out.println("Cooking Chicken Burger .");
    }
}

// Client
public class WithoutStrategyPattern {
    public static void main(String[] args) {
        Burger veggie = new VeggieBurger();
        Burger chicken = new ChickenBurger();

        veggie.prepare();
        veggie.cook();

        chicken.prepare();
        chicken.cook();
    }
}