interface CookingStrategy {
    void cook(String burgerName);
}


// 1. Strategy : Grilling
class GrillingStrategy implements CookingStrategy{
    @Override
    public void cook(String burgerName){
        System.out.println("Grilling the :" + burgerName);
    }
}


// 2. Strategy : Frying
class FryingStrategy implements CookingStrategy{
    @Override
    public void cook(String burgerName){
        System.out.println("Frying the :" + burgerName);
    }
}




class BurgerS {

    private String name;
    private CookingStrategy cookingStrategy;


    public BurgerS(String name, CookingStrategy cookingStrategy){
        this.name = name;
        this.cookingStrategy = cookingStrategy;
    }


    // Method for all kinds of Burgers and all kind of strategies --> general implementation
    public void prepare(){
        System.out.println("Preparing the Burger in General");
    }

    // Based on the cookingStrategy --> a specific cook() implmenetatin will be executed
    public void cook() {
        cookingStrategy.cook(name);
    }


    // On run time --> On the fly ---> Change the cooking Strategy
    public void setCookingStrategy(CookingStrategy cookingStrategy){
        this.cookingStrategy = cookingStrategy;
    }

}


// Ex: Add a New Strategy (Extend Code) as AirFryer
// your code

// Client
public class StrategyPattern {
    public static void main(String[] args) {


        BurgerS veggie = new BurgerS("Vegan Burger1",  new GrillingStrategy());
        veggie.prepare();
        veggie.cook();


        // Change the Strategy to Frying Strategy on the fly (In run time)
        veggie.setCookingStrategy(new FryingStrategy());
        veggie.cook();

        // your code


    }
}